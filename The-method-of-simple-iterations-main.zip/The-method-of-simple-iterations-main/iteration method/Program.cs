﻿using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

public class Program
{
    static double MyEquation(double x)
    {
        return Math.Cos(x / 2) / 2;
        //return -(2-Math.Tan(x))/5;
    }

    static void pr3()
    {
        double last = 0, beforeLast = 0.5;
        Console.WriteLine("{0,5}|{1,20}", "Предпоследний fi(x)", "Последний fi(x)");
        do
        {
            last = beforeLast;
            beforeLast = MyEquation(last);
            Console.WriteLine("{0,20}|{1,20}", last, beforeLast);
        } while (Math.Round(MyEquation(last), 5) != Math.Round(MyEquation(beforeLast), 5));
    }
    public static void Main()
    {
       new Program().Calclulate();
        //pr3();
        Console.ReadLine();
    }
    public void Calclulate()
    {
        EquationArgs equation = new EquationArgs();
        equation.CalculateTheDerivativeEvent += TheDerivative;
        equation.CalculateTheIterativeFunctionEvent += TheIterationFunction;
        equation.PrintIterativeFunctionEvent += PrintTheIterationFunction;
        equation.Epsilon = 0.0001;
        equation.StartIteration(0, 1);
    }
    private double TheDerivative(double x)
    {
        //return 1 / ((x + 2) * 2 * Math.Sqrt(x + 1));
        return - ((Math.Sin(x)/2)/4);
    }
    private double TheIterationFunction(double x)
    {
        //return Math.Atan(Math.Sqrt(x + 1));
        return Math.Cos(x/2)/2;
    }
    private string PrintTheIterationFunction(double x0)
    {
        //return $"arctg(sqrt({x0}+1))";
        return $"(2-cos({x0})) / 3";
    }
}
public class EquationArgs
{
    public delegate double CalculateTheDerivativeEventHandler(double x);
    public delegate double CalculateTheIterativeFunctionEventEventHandler(double x);
    public delegate string PrintIterativeFunctionEventHandler(double x0);

    public event CalculateTheDerivativeEventHandler CalculateTheDerivativeEvent = delegate { return 0.0; };
    public event CalculateTheIterativeFunctionEventEventHandler CalculateTheIterativeFunctionEvent = delegate { return 0.0; };
    public event PrintIterativeFunctionEventHandler PrintIterativeFunctionEvent = delegate { return ""; };
    public double Epsilon = 0.0001;
    private double CurrentEpsilon = 0.0002;

    public EquationArgs()
    {
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine("Метод простой итерации Численный метод " +
            "Один из простейших численных методов решения уравнений.Метод основан на принципе сжимающего отображения, который применительно к " +
            "численным методам в общем виде также может называться методом простой итерации или методом последовательных приближений. ");
        Console.ResetColor();
    }

    private double CalculateTheDerivative(double x)
    {
        return CalculateTheDerivativeEvent(x);
    }
    private double CalculateIterativeFunction(double x)
    {
        return CalculateTheIterativeFunctionEvent(x);
    }
    public void StartIteration(double a, double b)
    {
        int count = 0;
        double q1;
        double x0 = a > b ? a / 2 : b / 2;
        if (a >= 0 && b >= 0 || a < 0 && b < 0)
        {
            x0 = (a + b) / 2;
        }
        if (a < 0 && b >= 0)
        {
            x0 = (Math.Abs(a) + b) / 2;
            x0 = a + x0;
        }

        if (a >= 0 && b < 0)
        {
            x0 = (Math.Abs(b) + a) / 2;
            x0 = b + x0;
        }
        double last = 0;

        if (Math.Abs(CalculateTheDerivative(a)) > Math.Round(CalculateTheDerivative(b)))
        {
            q1 = Math.Abs(CalculateTheDerivative(a));
            Console.WriteLine($"q1 = max[{a};{b}] |f`(x)| = {q1}");
        }
        else
        {
            q1 = Math.Abs(CalculateTheDerivative(b));
  
            Console.WriteLine($"q1 = max[{a};{b}] |f`(x)| = {q1}");
        }
        q1 = Math.Abs(q1);
        q1 = q1;
        Console.WriteLine("q1 = " + q1);
        do
        {
            double f = Math.Round(CalculateIterativeFunction(x0), 5);
            if (count > 0) CurrentEpsilon = (q1 / (1 - q1) * (Math.Abs(f - last)));
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"Итерация {count + 1}: ");
            Console.ResetColor();
            Console.WriteLine($"\tfi({x0}) = {PrintIterativeFunctionEvent(x0)} = {Math.Round(f, 5)}");
            if (count > 0)
            {
                if (CurrentEpsilon > Epsilon)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"\tEpsilon = ({q1}/(1-{q1})) * |{f} - {last}| = {Math.Round(CurrentEpsilon, 5)} > {Math.Round(Epsilon, 5)}");
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"\tEpsilon = ({q1}/(1-{q1})) * |{f} - {last}| = {Math.Round(CurrentEpsilon, 5)} < {Math.Round(Epsilon, 5)}");
                    Console.ResetColor();
                    Console.WriteLine($"Ответ: x = {Math.Round(f, 4)}");
                }
            }

            x0 = f;
            last = f;
            count++;
        }
        while (CurrentEpsilon > Epsilon);
    }

}