﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace solving_systems_of_linear_algebraic_equations
{
    public class Program
    {
        static void Main(string[] args)
        {
            new Program().Calc();
        }
        public void Calc()
        {
            EquationSystem equationSystem = new EquationSystem();
            equationSystem.Print();
            equationSystem.ConveyMatrix();
            equationSystem.PrintConvented();
            equationSystem.StartIterations();
            Console.ReadLine();
        }
        public class EquationSystem
        {
            public double[,] matrix = new double[4, 4]
            {
                {20.9, 1.2, 2.1,0.9},
                {1.2,21.2,1.5,2.5},
                {2.1,1.5,19.8,1.3},
                {0.9,2.5,1.3,32.1 }
            };
            public double[] additional = new double[4]
            {
                21.70,27.46,28.76,49.72
            };
            public double[,] conveiedMatrix = new double[4, 5]
            {
                 {0,0,0,0,0},
                 {0,0,0,0,0},
                 {0,0,0,0,0},
                 {0,0,0,0,0},
            };
            public void StartIterations()
            {
                double[] cjs = new double[4];

                for (int i = 0; i < conveiedMatrix.GetLength(0); i++)
                {
                    double sum = 0;
                    for (int j = 2; j < conveiedMatrix.GetLength(1); j++)
                    {
                        sum += Math.Abs(conveiedMatrix[i, j]);
                    }
                    cjs[i] = Math.Round(sum / matrix[i, i], 3);
                }
                Console.Write("||C|| = max |Cij| = max {");
                for (int i = 0; i < cjs.Length; i++)
                {
                    Console.Write(cjs[i] + ",");
                }
                Console.Write("} = ");
                Console.WriteLine(cjs.Max());

                double[] values = new double[4];
                for (int i = 0; i < 4; i++)
                {
                    values[i] = Math.Round(conveiedMatrix[i, 1] / matrix[i, i],4);
                    Console.WriteLine($"{conveiedMatrix[i, 1]} / {matrix[i, i]} = {conveiedMatrix[i, 1] / matrix[i, i]}");
                }

                Console.Write("x0 = ");

                for (int i = 0; i < values.Length; i++)
                {
                    Console.WriteLine(values[i]);
                }


                int it = 1;



                while (it != 20)
                {
                    Console.WriteLine("Итервций " + it);
                    for (int i = 0; i < values.Length; i++)
                    {
                        values[i] =Math.Round(conveiedMatrix[i, 0] * (conveiedMatrix[i,1] + conveiedMatrix[i, 2] * values[1] + conveiedMatrix[i, 3] * values[2] + conveiedMatrix[i,4] * values[3]),4); 
                    }

                    for (int i = 0; i < values.Length; i++)
                    {
                        Console.WriteLine(values[i]);
                    }
                    it++;
                }

            }
            public void Print()
            {
                Console.WriteLine("{  ");
                for (int i = 0; i < matrix.GetLength(0); i++)
                {
                    Console.Write("|  ");
                    for (int j = 0; j < matrix.GetLength(1); j++)
                    {
                        Console.Write($"{matrix[i, j]}x{j + 1} + ");
                        if (j == matrix.GetLength(1) - 1)
                            Console.Write($"{matrix[i, j]}x{j + 1} = ");
                    }
                    Console.Write($" {additional[i]}");
                    Console.WriteLine();
                }
                Console.WriteLine("{  ");
            }
            public void PrintConvented()
            {
                Console.WriteLine("{  ");
                for (int i = 0; i < conveiedMatrix.GetLength(0); i++)
                {
                    Console.Write("|  ");
                    Console.Write($"x{i} = ");
                    for (int j = 0; j < conveiedMatrix.GetLength(1); j++)
                    {
                        if (j == 0)
                            Console.Write($"{conveiedMatrix[i, j]} (");
                        else
                            Console.Write($"{conveiedMatrix[i, j]} ");
                    }
                    Console.WriteLine(")");
                }
                Console.WriteLine("{  ");
            }
            public void ConveyMatrix()
            {
                int c = 0;
                for (int i = 0; i < matrix.GetLength(0); i++)
                {
                    conveiedMatrix[i, 0] = Math.Round(1 / matrix[i, c],4);
                    conveiedMatrix[i, 1] = additional[c];

                    for (int j = 1; j < matrix.GetLength(1) - 1; j++)
                    {
                        if (j == 2)
                            conveiedMatrix[i, 2] = -matrix[i, 0];
                        if (i == 0)
                            conveiedMatrix[i, 2] = -matrix[i, 1];
                        if (j != c)
                            conveiedMatrix[i, j + 1] = -matrix[i, j];
                        else
                            conveiedMatrix[i, j + 1] = -matrix[i, i - 1];
                    }
                    c++;
                }
                conveiedMatrix[3, 3] = -matrix[3, 1];
                conveiedMatrix[0, 4] = -matrix[0, 3];
                conveiedMatrix[1, 4] = -matrix[1, 3];
                conveiedMatrix[2, 4] = -matrix[2, 3];
                conveiedMatrix[3, 4] = -matrix[3, 2];
            }
        }
    }
}
